from Task import *
from ToDoList import *

if __name__ == '__main__':
    todo_list = TodoList()
    while True:
        print('\n-------- ToDoList menu ---------')
        print('1. Add Task')
        print('2. Remove task')
        print('3. Edit task')
        print('4. display all task')
        print('5. search task by name')
        print('6. search task by id')
        print('7. Mark task as done')
        print('8. Mark task as undone')
        print('9. Filter done Tasks')
        print('10. Filter undone Tasks')
        print('11. Exit')

        choice = input('Enter your choice (1 - 11)')

        if choice == '1':
            task_id = input("enter Task Id: ")
            title = input("Enter task title: ")
            new_task = Task(task_id, title)
            todo_list.add_task(new_task)
        elif choice == '2':
            task_id = input("enter task id to remove: ")
            todo_list.remove_task(task_id)
        elif choice == '3':
            task_id = input("enter Task Id: ")
            new_title = input("Enter task title: ")
            todo_list.edit_task(task_id, new_title)
        elif choice == '4':
            todo_list.display_all_task()
        elif choice == '5':
            keyword = input("enter keyword to search by name: ")
            todo_list.search_tasks_by_name(keyword)
        elif choice == '6':
            task_id = input("enter id for search by id: ")
            todo_list.search_tasks_by_id(task_id)
        elif choice == '7':
            task_id = input("enter task id to mark as done: ")
            if task_id in todo_list.tasks:
                todo_list.tasks[task_id].done()
                print(f"Task {task_id} marked as done.")
            else:
                print('task not found')
        elif choice == '8':
            task_id = input("enter task id to mark as done: ")
            if task_id in todo_list.tasks:
                todo_list.tasks[task_id].undone()
                print(f"Task {task_id} marked as undone.")
            else:
                print('task not found')
        elif choice == '9':
            todo_list.filter_done_tasks()
        elif choice == '10':
            todo_list.filter_undone_tasks()
        elif choice == '11':
            print('Good by dear user!')
            break
        else:
            print('Invalid choice: ')
