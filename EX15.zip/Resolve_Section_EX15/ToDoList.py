from Task import *


class TodoList:
    def __init__(self):
        self.tasks = {}

    def add_task(self, task):
        if task.id_t not in self.tasks:
            self.tasks[task.id_t] = task
            print('Task added!')
        else:
            print('task exists')

    def remove_task(self, task_id):
        if task_id in self.tasks:
            del self.tasks[task_id]
            print(f'Task with ID: {task_id} removed')
        else:
            print(f'task with id: {task_id} not found')

    def edit_task(self, task_id, new_title):
        if task_id in self.tasks:
            self.tasks[task_id].title = new_title
            print(f'Task with id: {task_id} updated')
        else:
            print(f'Task with id: {task_id} not found')

    def display_all_task(self):
        for task in self.tasks.values():
            print(task)

    def search_tasks_by_name(self, keyword):
        matching_tasks = []
        for task in self.tasks.values():
            if keyword.lower() in task.title.lower():
                matching_tasks.append(task)
            else:
                print('Not found!')

        for task1 in matching_tasks:
            print(task1)

    def search_tasks_by_id(self, task_id):
        if task_id in self.tasks:
            print(self.tasks[task_id])
        else:
            print(f'Task with Id: {task_id} not found')

    def filter_done_tasks(self):
        done_tasks = [task for task in self.tasks.values() if task.state]
        for task in done_tasks:
            print(task)

    def filter_undone_tasks(self):
        done_tasks = [task for task in self.tasks.values() if not task.state]
        for task in done_tasks:
            print(task)

