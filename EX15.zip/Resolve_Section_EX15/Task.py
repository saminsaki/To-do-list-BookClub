from datetime import datetime


class Task:
    def __init__(self, id_t, title, state=False, date_of_finishing=None):
        self.id_t = id_t
        self.title = title
        self.state = state
        self.date_of_finishing = date_of_finishing

    def done(self):
        self.state = True
        self.date_of_finishing = datetime.now()

    def undone(self):
        self.state = False
        self.date_of_finishing = None

    def __str__(self):
        return f'ID: {int(self.id_t)}, title: {self.title}'\
            f'state: {"completed" if self.state else "Uncompleted"}'\
            f'date of finishing: {self.date_of_finishing}'
